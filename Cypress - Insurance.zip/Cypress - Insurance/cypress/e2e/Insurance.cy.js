/**
 * 員工與眷屬保險作業 測試
 * @author Don
 */
import data from '../support/data.json';
import { EnterInsurance } from './Pages/Insurance.js';
import { EditInsurance } from './Pages/Insurance.js';

describe('編輯員工與眷屬保險作業', () => {

    // 每次 進入it前 執行登入
    beforeEach(() => {
        // 進行登入
        cy.enterLoginTest(
            "don0105",
            "admin",
            "888888"
        );
    });


    it('建立員工與眷屬保險作業資料', () => {

        // 實例化 進入員工與眷屬保險作業類別
        const enterinsurance = new EnterInsurance(data.insurance);
        // 實例化 編輯員工與眷屬保險作業類別
        const editinsurance = new EditInsurance(data.insurance);
        // 跳轉至 員工與眷屬保險作業 網址
        enterinsurance.navigate();

        // 輸入認證密碼
        // cy.get('.modal-content input[name="SecondPw"]').click().type('0979577', { force: true });
        // 認證密碼確認
        // cy.get('button#confirm').click();

        // 選擇選項並查詢
        enterinsurance.search();
        // 進入編輯 
        enterinsurance.edit();



        // 進行加保
        editinsurance.add();

        /*
        // 編輯目前歷程
        editinsurance.mode('edit','勞保加保');
        editinsurance.mode('edit','勞退加保');
        editinsurance.mode('edit','健保加保');
        */

        /*
        // 跳轉至 員工與眷屬保險作業 網址
        enterinsurance.navigate();
        // 進行級距調整
        editinsurance.intervalAdjust();
        // 選擇選項並查詢
        enterinsurance.search();
        // 進入編輯 
        enterinsurance.edit();
        */

        /*
        // 驗證 健保級距調整 試算表 - 個人
        editinsurance.verifyDollars('employee','健保級距調整', '30%', '426', '0%', '426');
        // 驗證 健保級距調整 試算表 - 單位
        editinsurance.verifyDollars('corporation','健保級距調整', '60%', '1329', '', '1329');
        // 驗證 健保級距調整 個人負擔參考金額
        editinsurance.verifyPersonDollars('健保級距調整','426');
        */

        /*
        // 查看目前歷程
        editinsurance.mode('view','勞保加保');
        editinsurance.mode('view','勞退加保');
        editinsurance.mode('view','健保加保');
        editinsurance.mode('view','勞保級距調整');
        editinsurance.mode('view','勞退級距調整');
        editinsurance.mode('view','健保級距調整');
        */

        // 進行薪調
        editinsurance.adjust();


        // 驗證 健保薪調 試算表 - 個人
        // editinsurance.verifyDollars('employee','健保薪調', '30%', '426', '0%', '426');
        // 驗證 健保薪調 試算表 - 單位
        // editinsurance.verifyDollars('corporation','健保薪調', '60%', '1329', '', '1329');
        // 驗證 健保薪調 個人負擔參考金額
        // editinsurance.verifyPersonDollars('健保薪調','426');


        /*
        // 編輯薪調歷程
        editinsurance.mode('edit','勞保薪調');
        editinsurance.mode('edit','勞退薪調');
        editinsurance.mode('edit','健保薪調');
        */

        
        // 進行眷屬加保
        editinsurance.dependentsAdd();
        // 進行眷屬調整
        editinsurance.dependentsAdjust();
        

        /*
        // 查看 眷屬加保 歷程
        editinsurance.mode('view','眷屬健保加保');
        // 編輯 眷屬調整 歷程
        editinsurance.mode('edit','眷屬健保調整');
        */


        // 進行眷屬轉出
        // editinsurance.dependentsTurnOut();
        // 進行本人轉出
        editinsurance.turnOut();

        /*
        // 編輯 轉出 歷程
        editinsurance.mode('edit','勞保轉出');
        editinsurance.mode('edit','勞退轉出');
        editinsurance.mode('edit','健保轉出');
        editinsurance.mode('edit','眷屬健保轉出');
        */
    });



    it('刪除/修改 歷程限制測試', () => {

        // 實例化 進入員工與眷屬保險作業類別
        const enterinsurance = new EnterInsurance(data.insurance);
        // 實例化 編輯員工與眷屬保險作業類別
        const editinsurance = new EditInsurance(data.insurance);
        // 跳轉至 員工與眷屬保險作業 網址
        enterinsurance.navigate();
        // 選擇選項並查詢
        enterinsurance.search();
        // 進入編輯 
        enterinsurance.edit();




        // 刪除 眷屬健保轉出 歷程 - 阻擋
        // editinsurance.deleteRowByType('眷屬健保轉出','blocked');
        // editinsurance.deleteRowByType('健保轉出');

        // 編輯 轉出歷程 - 阻擋
        // editinsurance.mode('edit','健保轉出','withoutHealth');
        // editinsurance.mode('edit','健保轉出','healthBlocked');
        // editinsurance.mode('edit','眷屬健保轉出','childBlocked');

        

        // 刪除單人所有歷程
        editinsurance.deleteAllHistory();

        // 刪除 data.insurance.deleteEmployeeId 中的人員歷程
        // editinsurance.caseDelete();
    });
})