// 進入網址類別
class Page {
  navigate(path) {
    return cy.visit(path)
  }
}
export { Page };