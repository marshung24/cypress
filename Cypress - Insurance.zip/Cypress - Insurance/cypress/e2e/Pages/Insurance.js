import { Page } from './pages.js';

/**
 * 進入 員工與眷屬保險作業 編輯頁面
 * @author Don Yan
 */
class EnterInsurance extends Page {
    /**
     * EnterInsurance 類別的建構函式。
     * @param {object} insuranceData - 與EnterInsurance類別相關的資料。
     */
    constructor(insuranceData) {
        // 呼叫父類別的建構函式
        super();
        // 設定保險資料屬性
        this.insuranceData = insuranceData;
        // 攔截發送到指定 URL 的 POST 請求，別名為 tw_ins_mg_ajaxEmpInsList
        cy.intercept('POST', `${Cypress.env('tw_ins_mg_ajaxEmpInsList')}`).as('tw_ins_mg_ajaxEmpInsList');
    }

    // 進入 員工與眷屬保險作業 網址
    navigate() {
        // 使用父類別的 navigate 方法並傳入網址
        return super.navigate(Cypress.env('insurance_url'));
    }

    /**
     * 員工與眷屬保險作業 按鈕
     * - search: 查詢
     */
    insuranceButton = {
        get search() { return cy.get('#filter') }
    }

    // 記錄選擇 100筆
    expendOptions() {
        cy.get('select[name="table_content_length"]').select("100");
    }

    // 查詢員工
    search() {
        // 使用解構賦值，從 this.insuranceData 中提取 Dpart 和 employeeId 屬性的值
        const { Dpart, employeeId } = this.insuranceData;
        // 選取部門
        cy.get("#SLayer3").select(Dpart, { force: true });
        // 點擊查詢
        this.insuranceButton.search.click();
        // 此處先進行強制等待
        cy.wait(1000);
        // 關鍵字填入 employeeId
        cy.get("#table_content_filter").find('input[type="search"]').clear().type(employeeId);
    }

    // 點擊編輯
    edit() {
        // 點擊編輯
        cy.get('#modify').click();
        // 等待 進入 員工與眷屬保險作業 個人頁面完成
        cy.wait('@tw_ins_mg_ajaxEmpInsList').then((interception) => {
            return;
        });
        // 記錄選擇 100筆
        this.expendOptions();


    }

}
export { EnterInsurance };


/**
 * 編輯 員工與眷屬保險作業 
 * @author Don Yan
 */
class EditInsurance {
    /**
     * EditInsurance 類別的建構函式。
     * @param {object} insuranceData - 與EditInsurance類別相關的資料。
     */
    constructor(insuranceData) {
        // 設定保險資料屬性
        this.insuranceData = insuranceData;
        // 呼叫類別內的 intercept 方法，執行攔截操作
        this.intercept();
    }

    // 攔截 tw_ins_mg_ajaxCrudForm \ tw_ins_mg_ajaxEmpInsList
    intercept() {
        // 攔截發送到指定 URL 的 POST 請求，別名為 tw_ins_mg_ajaxCrudForm
        cy.intercept('POST', `${Cypress.env('tw_ins_mg_ajaxCrudForm')}`).as('tw_ins_mg_ajaxCrudForm');
        // 攔截發送到指定 URL 的 POST 請求，別名為 tw_ins_mg_ajaxEmpInsList'
        cy.intercept('POST', `${Cypress.env('tw_ins_mg_ajaxEmpInsList')}`).as('tw_ins_mg_ajaxEmpInsList');
    }

    /**
     * 員工與眷屬保險作業 按鈕
     * - search: 查詢
     */
    insuranceButton = {
        get search() { return cy.get('#filter') }
    }
    // 記錄選擇 100筆
    expendOptions() {
        cy.get('select[name="table_content_length"]').select("100");
    }
    // 級距調整
    intervalAdjust() {
        // 點擊級距調整
        cy.get('input[name="empLevelAdjustBatch"][dataname="empLevelAdjustBatch"][dataaction="add"]').click();
        // 等待 打開級距調整彈窗 完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 點擊更新
            cy.get('#ModalSave').click();
        });
        // 等待 更新完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            return;
        });
    }
    // 加保
    add() {
        // 從 this.insuranceData.add 中解構取得相應的屬性值
        const {
            id,
            birthday,
            country,
            insuranceUnit,
            insuranceDate,
            effectiveDate,
            disability,
            salary,
            remark
        } = this.insuranceData.add;

        // 點擊 加保
        cy.get('#addInsurance').should('be.visible').click();
        // 等待 點擊加保後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 此套件須在抓取後強制等待(100~200)ms,否則會抓取不到元素
            // 輸入 身分證字號
            cy.get('#id_no').should('be.visible').wait(200).clear().type(id);
            // 輸入 出生年月日
            cy.get('#birthday').should('be.visible').wait(100).clear().type(`${birthday}{enter}`);
            // 選擇 國別
            cy.get('#u_country').should('be.visible').wait(100).select(country);
            // 選擇 投保單位
            cy.get('#iu_sn').should('be.visible').wait(100).select(insuranceUnit)
            // 輸入 加保日期
            cy.get('#add_date').should('be.visible').wait(100).clear().type(`${insuranceDate}{enter}`);
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(100).clear().type(`${effectiveDate}{enter}`);
            // 保險身分 點擊 雇主
            cy.get('#ins_status_2').wait(100).click();
            // 保險身分 點擊 員工
            cy.get('#ins_status_1').wait(100).click();
            // 選擇 身心障礙等級
            cy.get('#disability_level').should('be.visible').wait(100).select(disability);
            // 輸入 月投保薪資
            cy.get('#ins_salary').should('be.visible').wait(100).clear().type(salary);
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
            // 選擇健保補助項目,scrollIntoView 須往下滑動至元素可見
            cy.get('#subsidy_eligibility').scrollIntoView().should('be.visible').wait(100).select('無');
        })
        // 點擊 儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    // 薪調
    adjust() {
        // 從 this.insuranceData.adjust 中解構取得相應的屬性值
        const {
            effectiveDate,
            salary,
            remark
        } = this.insuranceData.adjust;
        // 點擊 薪調
        cy.get('#salaryAdjust').should('be.visible').click();
        // 等待 點擊薪調後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 此套件須在抓取後強制等待(100~200)ms,否則會抓取不到元素
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(100).clear().type(`${effectiveDate}{enter}`);
            // 輸入 月投保薪資
            cy.get('#ins_salary').should('be.visible').wait(100).clear().type(salary);
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
        })
        // 點擊儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    // 眷屬健保加保
    dependentsAdd() {
        // 從 this.insuranceData.childAdd 中解構取得相應的屬性值
        const {
            name,
            id,
            birthday,
            relationship,
            insuranceDate,
            effectiveDate,
            disability,
            insuranceConditions,
            allowance,
            remark
        } = this.insuranceData.childAdd;
        // 點擊 眷屬健保加保
        cy.get('#dependentsAddIns').should('be.visible').click();
        // 等待 點擊眷屬健保加保後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 此套件須在抓取後強制等待(100~200)ms,否則會抓取不到元素
            // 選擇 眷屬姓名 - 新增眷屬
            cy.get('#uf_sn').should('be.visible').wait(500).select('新增眷屬')
            // 輸入 眷屬姓名
            cy.get('#familyMember').wait(100).clear().type(name);
            // 點擊 性別 女
            cy.get('#gender_0').wait(100).click();
            // 點擊 性別 男
            cy.get('#gender_1').wait(100).click();
            // 輸入 身分證字號
            cy.get('#id_no').should('be.visible').wait(100).clear().type(id);
            // 輸入 出生年月日
            cy.get('#birthday').should('be.visible').wait(100).clear().type(`${birthday}{enter}`);
            // 選擇 關係
            cy.get('#relationship').should('be.visible').wait(100).select(relationship);
            // 輸入 加保日期
            cy.get('#add_date').should('be.visible').wait(100).clear().type(`${insuranceDate}{enter}`);
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(100).clear().type(`${effectiveDate}{enter}`);
            // 選擇 身心障礙等級
            cy.get('#disability_level').should('be.visible').wait(100).select(disability);
            // 選擇 補助項目
            cy.get('#subsidy_project').should('be.visible').wait(100).select('無');
            /*
            // 選擇 補助項目 複選 (未上線)
            cy.get('[data-id="subsidy_project"]').click();
            allowance.forEach((option) => {
                cy.get('.dropdown-menu').contains(option).click();
            });
            */
            // 點擊 補助設定 - 同時補助
            cy.get('#subsidy_status_2').wait(100).click();
            // 點擊 補助設定 - 擇優補助
            cy.get('#subsidy_status_1').wait(100).click();
            // 選擇 投保條件
            cy.get('#ins_condition').should('be.visible').wait(100).select(insuranceConditions);
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
        });
        // 點擊儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    // 眷屬健保調整
    dependentsAdjust() {
        // 從 this.insuranceData.childAdjust 中解構取得相應的屬性值
        const {
            name,
            effectiveDate,
            disability,
            allowance,
            insuranceConditions,
            remark
        } = this.insuranceData.childAdjust;
        // 點擊 眷屬健保調整
        cy.get('#dependentsAdjustIns').should('be.visible').click();
        // 等待 點擊眷屬健保調整後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 此套件須在抓取後強制等待(100~200)ms,否則會抓取不到元素
            // 選擇 眷屬姓名
            cy.get('#uf_sn').should('be.visible').wait(100).select(name)
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(100).clear().type(`${effectiveDate}{enter}`);
            // 選擇 身心障礙等級
            cy.get('#disability_level').should('be.visible').wait(100).select(disability);
            // 選擇 補助項目
            cy.get('#subsidy_project').should('be.visible').wait(100).select('無');
            /*
            // 選擇 補助項目 複選 (未上線)
            cy.get('[data-id="subsidy_project"]').click();
            allowance.forEach((option) => {
                cy.get('.dropdown-menu').contains(option).click();
            });
            */
            // 點擊 補助設定 - 擇優補助
            cy.get('#subsidy_status_1').wait(100).click();
            // 點擊 補助設定 - 同時補助
            cy.get('#subsidy_status_2').wait(100).click();
            // 選擇 投保條件
            cy.get('#ins_condition').should('be.visible').wait(100).select(insuranceConditions);
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
        });
        // 點擊儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    // 眷屬健保轉出
    dependentsTurnOut() {
        // 從 this.insuranceData.childTurnOut 中解構取得相應的屬性值
        const {
            effectiveDate,
            remark
        } = this.insuranceData.childTurnOut;
        // 點擊 眷屬健保轉出
        cy.get('#dependentsTurnOut').should('be.visible').click();
        // 等待 點擊眷屬健保轉出後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(500).clear().type(`${effectiveDate}{enter}`);
            // 點擊第一個checkbox
            cy.get('.checkbox input[type="checkbox"]').eq(0).click();
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
        });
        // 點擊儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    // 本人轉出
    turnOut() {
        // 從 this.insuranceData.turnOut 中解構取得相應的屬性值
        const {
            effectiveDate,
            remark
        } = this.insuranceData.turnOut;
        // 點擊 轉出
        cy.get('#turnOut').should('be.visible').click();
        // 等待 點擊轉出後請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 輸入 生效日期
            cy.get('#start_date').should('be.visible').wait(500).clear().type(`${effectiveDate}{enter}`);
            // 輸入 備註
            cy.get('#remark').should('be.visible').wait(100).clear().type(remark);
        });
        // 儲存
        cy.get('#ModalSave').wait(100).click();
        // 儲存後等待請求完成
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            return;
        });
    }
    /**
     * 執行操作模式，包括查看（view）和修改（edit）
     * @param {string} action - 執行的操作，可選值為 'view' 或 'edit'
     * @param {string} type - 類型，指定要查看或修改的項目類型
     * @param {string} message - 用於阻擋的訊息，可選值為 'healthBlocked' 或 'childBlocked'
     */
    mode(action, type, message) {
        // 從 this.insuranceData 中取得特定的生效日期
        const healthTurnOutDay = this.insuranceData.turnOut.effectiveDate;
        const childTurnOutDay = this.insuranceData.childTurnOut.effectiveDate;

        // 找到包含 "type" 文字的 <td> 元素所在的列
        cy.contains('td', type).parent('tr').as('targetRow');
        // 等待目標行出現，然後點擊修改按鈕
        cy.get('@targetRow').find('#modify').click();
        // 等待 點擊修改 請求完成後 再進行後續操作 
        cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
            // 檢查攔截到的請求的狀態碼是否等於 200
            expect(interception.response.statusCode).to.equal(200);
            // 此套件須在抓取後強制等待1s,否則會抓取不到元素
            if (action === 'view') {
                // 如果是查看操作，點擊 關閉
                cy.get('#ModalClose').wait(1000).click();
                return;
            } else {
                // 如果是修改操作
                // 此套件須在抓取後強制等待(100~200)ms,否則會抓取不到元素
                if (message === 'withoutHealth') {
                    // 阻擋 本人 修改生效日期 < 加保日期
                    // 輸入 生效日期 1912-01-01
                    cy.get('#start_date').should('be.visible').wait(500).clear().type('1912-01-01');
                    // 點擊 儲存
                    cy.get('#ModalSave').wait(1000).click();
                    // 儲存後等待請求完成
                    cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                        // 判斷 message 應包含指定文字
                        expect(interception.response.body.message).to.include(`員工未加保`);
                        // 點擊 關閉
                        cy.get('#ModalClose').click();
                    });

                }
                else if (message === 'healthBlocked') {
                    // 阻擋 本人轉出日期 < 眷屬健保轉出日期

                    // 將 眷屬轉出日期 減去1天
                    // 將日期字串轉換為 JavaScript 的 Date 物件
                    const currentDate = new Date(childTurnOutDay);
                    // 減去一天
                    currentDate.setDate(currentDate.getDate() - 1);
                    // 將結果轉換回字串格式
                    const newDateStr = currentDate.toISOString().split('T')[0];

                    // 輸入 生效日期 newDateStr
                    cy.get('#start_date').should('be.visible').wait(500).clear().type(`${newDateStr}`);
                    // 點擊 儲存
                    cy.get('#ModalSave').wait(1000).click();
                    // 儲存後等待請求完成
                    cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                        // 判斷 message 應包含指定文字
                        expect(interception.response.body.message).to.include(`員工資料錯誤：生效日期必須 大於等於 眷屬健保轉出動作的生效日期(${childTurnOutDay})`);
                        // 點擊 關閉
                        cy.get('#ModalClose').click();
                    });

                } else if (message === 'childBlocked') {
                    // 阻擋 眷屬健保轉出日期 > 本人轉出日期

                    // 將 眷屬轉出日期 加1天
                    // 將日期字串轉換為 JavaScript 的 Date 物件
                    const currentDate = new Date(healthTurnOutDay);
                    // 減去一天
                    currentDate.setDate(currentDate.getDate() + 1);
                    // 將結果轉換回字串格式
                    const newDateStr = currentDate.toISOString().split('T')[0];

                    // 輸入 生效日期 newDateStr
                    cy.get('#start_date').should('be.visible').wait(500).clear().type(`${newDateStr}`);
                    // 點擊 儲存
                    cy.get('#ModalSave').wait(1000).click();
                    // 儲存後等待請求完成
                    cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                        // 判斷 message 應包含指定文字
                        expect(interception.response.body.message).to.include(`眷屬資料錯誤：生效日期必須 小於等於 健保轉出動作的生效日期(${healthTurnOutDay})`);
                        // 點擊 關閉
                        cy.get('#ModalClose').click();
                    });
                } else {
                    // 點擊 儲存
                    cy.get('#ModalSave').wait(1000).click();
                    // 儲存後等待請求完成
                    cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                        // 檢查攔截到的請求的狀態碼是否等於 200
                        expect(interception.response.statusCode).to.equal(200);
                        return;
                    });
                }
            }
        });
    }
    /**
     * // 指定刪除某一列資料
     * @param {string} type - 要刪除的資料類型
     * @param {string} message - 用於阻擋的訊息，可選值為 'blocked'
     */
    deleteRowByType(type, message) {
        // 取得所有td
        cy.get('td')
            // Cypress 中 雖然index 無使用但不可刪除
            .filter((index, element) => {
                // 去除文本內容兩側的空格字符
                const cellText = element.textContent.trim();
                // 找到包含 "type" 文字的 <td> 元素所在的列
                return cellText === type;
            })
            // 將找到的表格行元素設定為別名 'targetRow'
            .parent('tr')
            .as('targetRow');
        // 等待目標行出現，然後點擊刪除按鈕
        cy.get('@targetRow').find('#delete').wait(200).click();
        // 套件問題需等待 500 毫秒，然後點擊 "是" 按鈕
        cy.wait(500).then(() => {
            // 點擊 "是" 按鈕 , 抓取是後須強制等待200ms再點擊
            cy.get('.popover-content').find('#delete').should('be.visible').wait(200).click();
            // 判斷是否應阻擋
            if (message === 'blocked') {
                // 等待刪除完成
                cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                    // 判斷 message 應包含指定文字
                    expect(interception.response.body.message).to.include('員工已轉出，不可刪除眷屬健保轉出資料');
                });
            } else {
                // 等待刪除完成
                cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                    // 檢查攔截到的請求的狀態碼是否等於 200
                    expect(interception.response.statusCode).to.equal(200);
                });
            }
        });
    }
    /**
     * 驗證 試算表金額
     * @param {string} unit - 試算表的單位，可選值為 'employee' 或其他（代表公司)
     * @param {string} type - 試算表的類型
     * @param {string} rateEmp - 員工或公司的比例
     * @param {string} initDollars - 初始金額
     * @param {string} subsidyRate - 補助比例
     * @param {string} totalDollars - 試算表小計
     */
    verifyDollars(unit, type, rateEmp, initDollars, subsidyRate, totalDollars) {
        // 找到包含 "type" 文字的 <td> 元素所在的列,並設定為別名 'targetRow'
        cy.contains('td', type).parent('tr').as('targetRow');
        // 等待目標行出現，然後點擊修改按鈕
        cy.get('@targetRow').find('#modify').click();

        if (unit === 'employee') {
            // 驗證員工
            // 等待 點擊修改後請求完成
            cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                // 檢查攔截到的請求的狀態碼是否等於 200
                expect(interception.response.statusCode).to.equal(200);
                // 驗證 比例
                cy.get('.trialBodyEven.rateEmp').contains(rateEmp);
                // 驗證 初始金額
                cy.get('.trialBodyEven.nhiPayEmpNS').contains(initDollars);
                // 驗證 補助比例
                cy.get('.trialBodyEven.subsidy').contains(subsidyRate);
                // 驗證 試算小計
                cy.get('.trialBodyEven.nhiPayEmp').contains(totalDollars);
            });
        } else {
            // 驗證公司
            // 等待 點擊修改後請求完成
            cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                expect(interception.response.statusCode).to.equal(200);
                // 驗證 比例
                cy.get('.trialBodyOdd.rateComp').contains(rateEmp);
                // 驗證 初始金額
                cy.get('.trialBodyOdd.nhiPayComp').contains(initDollars);
                // 驗證 試算小計
                cy.get('.trialBodyOdd.nhiPayComp').contains(totalDollars);
            });
        }
        // 點擊 關閉
        cy.get('#ModalClose').wait(1000).click();
    }
    /**
     * 
     * @param {string} type - 類型
     * @param {string} dollars - 個人負擔金額參考值
     */
    verifyPersonDollars(type, dollars) {
        // 在表格中找到包含指定 "type" 文字的表格行
        cy.get(`tbody tr:contains(${type})`)
            .within(() => {
                // 驗證該行中的 "個人負擔金額參考" 欄位是否等於指定的金額
                cy.get('td[data-th="個人負擔金額參考"]').contains(dollars);
            });
    }

    // deBug 用 , 用於顯示 歷程數量
    historyLength() {
        cy.get('#table_content tbody tr').then((rows) => {
            console.log(rows.length);
        });
    }

    // 刪除所有歷程,無歷程回至首頁
    // 當眷屬轉出是以本人轉出而連帶轉出時,會產生bug導致刪除計數錯誤,目前待解決
    deleteAllHistory() {
        // 判斷是否仍有歷程
        cy.get('#table_content tbody tr').then((rows) => {
            // 若為 無符合資料 , 則跳轉到 員工與眷屬保險作業 主頁
            if (rows[0].firstElementChild.innerText === '無符合資料') {
                cy.visit(Cypress.env('insurance_url'));
            } else {
                // 記錄歷程行數
                this.rowCount = rows.length;
                // 判斷 是否同時存在 健保轉出 和 健保眷屬轉出
                // 取得所有包含指定文字的 td 元素 , Cypress 中 index 無使用仍不可刪除
                cy.get('td').filter((index, element) => {
                    // 去除文本內容兩側的空格字符
                    const cellText = element.textContent.trim();
                    // 找到包含 "眷屬健保轉出" 或 "健保轉出" 文字的 <td> 元素所在的列
                    return cellText === '眷屬健保轉出' || cellText === '健保轉出';
                }).then((matchingTds) => {
                    // 若 matchingTds.length > 1 , 代表 眷屬健保轉出 和 健保轉出 同時存在,先刪除 健保轉出
                    if (matchingTds.length > 1) {
                        // 先刪除 健保轉出
                        this.deleteRowByType('健保轉出');
                        // 使用 then 解決非同步問題 再執行其他操作
                        cy.get('#table_content tbody tr').then(() => {
                            // 減少行數計數
                            this.rowCount--;
                            console.log(this.rowCount);
                        });
                    }
                });
                // 呼叫刪除歷程的函式
                deleteHistory();
            }
        })

        // 刪除歷程函式
        const deleteHistory = () => {
            // 使用 then 解決非同步問題 再執行其他操作
            cy.get('#table_content tbody tr').then(() => {
                // 點擊刪除按鈕
                cy.get('#delete').click();
                // 套件問題需等待 500 毫秒，然後點擊 "是" 按鈕
                cy.wait(500).then(() => {
                    // 點擊 "是" 按鈕 , 抓取是後套件問題須強制等待200ms再點擊
                    cy.get('.popover-content').find('#delete').should('be.visible').wait(200).click();
                });
                // 等待刪除完成
                cy.wait('@tw_ins_mg_ajaxCrudForm').then((interception) => {
                    // 檢查攔截到的請求的狀態碼是否等於 200
                    expect(interception.response.statusCode).to.equal(200);
                    // 使用 then 解決非同步問題 再執行其他操作
                    cy.get('#table_content tbody tr').then(() => {
                        // 減少行數計數
                        this.rowCount--;
                        if (this.rowCount === 0) {
                            // 若行數為零，則返回首頁
                            cy.visit(Cypress.env('insurance_url'));
                            return;
                        } else {
                            // 遞迴進行下一次迭代
                            deleteHistory();
                        }
                    });
                })
            });
        };
    }
    // 逐一刪除 data.insurance.deleteEmployeeId 中的案例
    caseDelete() {
        // 使用 cy.wrap 以處理非同步問題
        cy.wrap(this.insuranceData.deleteEmployeeId).each((deleteEmployeeId) => {
            // 選取部門,此處須強制選擇以確保生效
            cy.get("#SLayer3").select("全部", { force: true });
            // 點擊查詢
            this.insuranceButton.search.click();
            // 此處先進行強制等待
            cy.wait(1000);
            // 關鍵字填入 deleteEmployeeId
            cy.get("#table_content_filter").find('input[type="search"]').clear().type(deleteEmployeeId);
            // 點擊修改
            cy.get('#modify').click();
            // 等待進入個人頁面的完成
            cy.wait('@tw_ins_mg_ajaxEmpInsList').then(() => {
                return;
            });
            // 執行歷程刪除
            this.deleteAllHistory();
        });
    }
}
export { EditInsurance };

