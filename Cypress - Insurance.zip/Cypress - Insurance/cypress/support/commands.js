// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

/**
 * 系統登入
 * @author Don Yan
 */
Cypress.Commands.add('enterLoginTest', (dept, username, password) => {
  // 使用 Cypress 的 session 命令，模擬使用者登入，設定部門、使用者名稱和密碼
  cy.session([dept, username, password], () => {
    // 訪問指定的登入頁面
    cy.visit(Cypress.env('login_url'));
    // 輸入部門資訊
    cy.get('#dept_input').type(dept);
    // 輸入使用者名稱
    cy.get('#username_input').type(username);
    // 輸入密碼
    cy.get('#password-input').type(password);
    // 點擊登入按鈕
    cy.get('#login-button').click();
  });
});


