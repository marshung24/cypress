const { defineConfig } = require("cypress");

module.exports = defineConfig({
  viewportWidth: 1600,
  viewportHeight: 1200,
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    baseUrl: 'https://harvey-autotest.rd1.nueip.site/'
  },
  env: {
    home_url: '/home',
    login_url: '/login',
    accountMg_url: '/account_management',
    accountMg_ajax: '/account_management/ajax',
    accountQk_url: '/newstaff_setting',
    subjectMg_url: '/payroll_item',
    subjectItem_ajax: '/payroll_item/ajax/*',
    payroll_api: '/payroll_mngt/payroll/api',
    payroll_mngt_item: '/payroll_mngt/item/*',
    payroll_mngt: '/payroll_mngt/payroll/api/*',
    payroll_basic_api: '/payroll_mngt/basic/api',
    payroll_mngt_basic: '/payroll_mngt/basic/api/*',
    payroll_tax_api: '/payroll_mngt/tax/api',
    payroll_mngt_tax: '/payroll_mngt/tax/api/*',
    structure_url: '/salary/salary_structure',
    payrollMg_url: '/payroll_management',
    deptChain: '/widget/deptChain/getUserDeptMap',
    paySettle_url: '/salary_calculation',
    paymentDate_ajax: '/shared/org_tree_popover_ajax',
    getPayrollItemTreeBasic: '/salary/api/SalaryStructure/getPayrollItemTree/base',
    getPayrollItemTreeDeduct: '/salary/api/SalaryStructure/getPayrollItemTree/sub',
    getPayrollItemTreePayable: '/salary/api/SalaryStructure/getPayrollItemTree/add',
    insurance_url: '/tw_ins_management',
    tw_ins_mg_ajaxEmpInsList: '/tw_ins_management/ajaxEmpInsList',
    tw_ins_mg_ajaxCrudForm: '/tw_ins_management/ajaxCrudForm',
    attendanceRecord_url: '/attendance_record',
    attendanceRecord_ajax: '/attendance_record/ajax'
  },
});

